// log-hook.js — 加载期钩子(起源管理器): 日志累积 + mod 停用拦截
// 必须走 scriptFileList_inject_early: 在后续 mod 的加载之前注册钩子。
// ModLoader 的 LogWrapper 无历史回放, 只能自己攒; canLoadThisMod 只能拦
// "排在本 mod 之后"加载的 mod(源码 ModLoader.ts filterModCanLoad 注释),
// 因此本管理器应排在 Mod Loader 列表尽量靠前。
(function () {
  'use strict';
  if (window.__susatoLogHook) return;
  var SELF = '起源框架';
  var MODS_OFF_KEY = 'susato_mods_off';
  var store = { entries: [] };
  window.__susatoLogHook = store;

  function push(level, msg) {
    try {
      if (store.entries.length >= 2000) return; // 防失控
      store.entries.push({ level: level, msg: String(msg) });
    } catch (e) {}
  }

  function modsOff() {
    try {
      var arr = JSON.parse(localStorage.getItem(MODS_OFF_KEY));
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }

  try {
    var lc = window.modModLoadController ||
      (window.modSC2DataManager && window.modSC2DataManager.getModLoadController && window.modSC2DataManager.getModLoadController());
    if (lc && typeof lc.addLifeTimeCircleHook === 'function') {
      lc.addLifeTimeCircleHook('susato-manager-log-hook', {
        logInfo: function (m) { push('info', m); },
        logWarning: function (m) { push('warning', m); },
        logError: function (m) { push('error', m); },
        // mod 开关: 名字在停用清单里就拦下(不删本体, 清单移除后下次加载恢复)。
        // 绝不拦自己, 任何异常放行。
        canLoadThisMod: function (bootJson) {
          try {
            if (!bootJson || !bootJson.name || bootJson.name === SELF) return Promise.resolve(true);
            if (modsOff().indexOf(bootJson.name) >= 0) {
              push('warning', '[起源管理器] 按开关停用: ' + bootJson.name);
              return Promise.resolve(false);
            }
          } catch (e) {}
          return Promise.resolve(true);
        },
      });
      store.registered = true;
    }
  } catch (e) {}
})();
