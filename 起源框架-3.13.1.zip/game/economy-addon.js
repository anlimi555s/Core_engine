// economy-addon.js — susato-model 经济框架（G2 地基）
// 注册式周期结算：支出/收入/债务条目，日界结算，账本面板。
// 对标 skill-addon/clothing-addon：框架在主 mod，内容 mod 只声明条目。
//
// API:
//   SusatoModel.economy.add({
//     id: 'baileyExtortion',        // 唯一 id
//     name: '贝利的保护费',          // 账本显示名
//     kind: 'expense',              // expense | income | debt
//     amount: 50000,                // 每期金额（便士），可以是函数
//     period: 7,                    // 结算周期（天）
//     active: function () {},      // 启用条件，返回 bool（默认恒真）
//     principal: 1000000,           // debt 专用：初始本金（便士），可以是函数
//     interest: 0,                  // debt 专用：每期利率（百分数，如 5 = 5%）
//     silent: false,                // true 则不发默认结算提示
//     selfPay: false,               // income 专用：true 则框架不往口袋发钱，
//                                   //   只调 money(amt, id, {recordOnly}) 记统计，
//                                   //   实际入账由 onSettle 自己完成（如存进储蓄）
//     payWith: function (amt) {},   // debt 专用：自定义扣款来源，返回是否付成功。
//                                   //   资金移动和统计记账全部由该函数自己负责。
//                                   //   缺省时框架只检查并扣口袋现金。
//     onSettle: function (amt) {},  // 结算成功回调
//     onDefault: function (amt) {}, // 付不起回调
//     onPaidOff: function () {},    // debt 专用：还清回调
//   })
//   SusatoModel.economy.state(id)   -> { lastDay, missed, arrears, principal }
//   SusatoModel.economy.reset(id)   -> 删除条目存档状态；下次激活时重新建档
//                                      （debt 重借/还清必须调用，否则沿用陈旧 lastDay/principal）
//   SusatoModel.economy.notify(str) -> 追加一条结算提示（下个 passage 显示）
//   SusatoModel.economy.hasVisible()-> 是否有激活条目（账本按钮显隐用）
//
// 存档状态: $susatoEcon = { v: 1, entries: { id: {...} }, notices: [] }
// 账本面板: <<susatoEconPanel>>（DefineMacroS），由 SusatoModel.ui.openPanel 渲染
// 让你们不还贝利的钱，现在我就要你们强行出
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('economy-addon')) return; // 模块开关(起源管理器), 刷新后生效

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.economy) return; // load-once 守卫
  if (!SM.onInit) {
    // susato-core 未加载时提供最小 onInit 兜底
    SM._initHooks = SM._initHooks || [];
    SM.onInit = function (fn) { SM._initHooks.push(fn); };
  }

  var _entries = {};   // id -> config
  var _order = [];     // 注册顺序

  function _V() {
    return (typeof State !== 'undefined' && State.variables) ? State.variables : null;
  }

  function _resolve(v, fallback) {
    try {
      if (typeof v === 'function') return Number(v()) || 0;
      if (v === undefined || v === null) return fallback || 0;
      return Number(v) || 0;
    } catch (e) { return fallback || 0; }
  }

  function _store() {
    var V = _V();
    if (!V) return null;
    if (!V.susatoEcon || typeof V.susatoEcon !== 'object') {
      V.susatoEcon = { v: 1, entries: {}, notices: [] };
    }
    if (!V.susatoEcon.entries) V.susatoEcon.entries = {};
    if (!V.susatoEcon.notices) V.susatoEcon.notices = [];
    return V.susatoEcon;
  }

  function _isActive(cfg) {
    try { return cfg.active ? !!cfg.active() : true; } catch (e) { return false; }
  }

  // 扣钱/给钱：优先走本体 money() 保持统计兼容，不可用则直接改 V.money
  function _pay(amount, tag) {
    var V = _V();
    if (!V) return;
    try {
      if (typeof window.money === 'function') {
        window.money(amount, tag || 'susatoEcon');
        return;
      }
    } catch (e) {}
    V.money = Math.max(0, (V.money || 0) + amount);
  }

  // 只记统计不动余额（selfPay 收入用；本体 money() 的 recordOnly 选项）
  function _record(amount, tag) {
    try {
      if (typeof window.money === 'function') {
        window.money(amount, tag || 'susatoEcon', { recordOnly: true });
      }
    } catch (e) {}
  }

  function _fmt(pence) {
    var v = Math.round(pence) / 100;
    return '£' + v.toLocaleString('en-GB', { maximumFractionDigits: 2 });
  }

  var SE = SM.economy = {
    add: function (config) {
      if (!config || !config.id || _entries[config.id]) return;
      if (!config.kind) config.kind = 'expense';
      if (!config.period || config.period < 1) config.period = 7;
      _entries[config.id] = config;
      _order.push(config.id);
    },
    get: function (id) { return _entries[id]; },
    state: function (id) {
      var s = _store();
      return s ? s.entries[id] : null;
    },
    reset: function (id) {
      var s = _store();
      if (s && s.entries[id]) delete s.entries[id];
    },
    notify: function (str) {
      if (!str) return;
      // state-addon 在场时走统一消息系统（$susatoNotices），缺席时回退自有队列
      if (typeof SM.notify === 'function') { SM.notify(String(str), 'gold'); return; }
      var s = _store();
      if (s) s.notices.push(String(str));
    },
    hasVisible: function () {
      try {
        for (var i = 0; i < _order.length; i++) {
          var cfg = _entries[_order[i]];
          if (_isActive(cfg)) return true;
          var st = _store() && _store().entries[cfg.id];
          if (st && (st.arrears > 0 || st.principal > 0)) return true;
        }
      } catch (e) {}
      return false;
    },
    fmt: _fmt,
  };

  // ---------------- 结算核心 ----------------

  function _settleEntry(cfg, st, today) {
    var guard = 0;
    while (today - st.lastDay >= cfg.period && guard < 24) {
      guard++;
      st.lastDay += cfg.period;
      var amt = _resolve(cfg.amount, 0);

      if (cfg.kind === 'income') {
        if (amt > 0) {
          // selfPay：入账由 onSettle 自己完成（如存进储蓄），框架只记统计
          if (cfg.selfPay) _record(amt, cfg.id);
          else _pay(amt, cfg.id);
        }
        if (!cfg.silent) SE.notify('入账：' + (cfg.name || cfg.id) + ' ' + _fmt(amt) + '。');
        try { if (cfg.onSettle) cfg.onSettle(amt); } catch (e) {}
        continue;
      }

      if (cfg.kind === 'debt') {
        // 先计息，再还款
        var rate = _resolve(cfg.interest, 0);
        if (rate > 0 && st.principal > 0) {
          st.principal = Math.round(st.principal * (1 + rate / 100));
        }
        var payment = Math.min(amt, st.principal);
        if (payment <= 0) continue;
        var paid = false;
        if (typeof cfg.payWith === 'function') {
          // 自定义扣款来源（资金移动 + 统计记账由 payWith 自己负责）
          try { paid = !!cfg.payWith(payment); } catch (e) { paid = false; }
        } else {
          var V = _V();
          if (V && (V.money || 0) >= payment) {
            _pay(-payment, cfg.id);
            paid = true;
          }
        }
        if (paid) {
          st.principal -= payment;
          if (!cfg.silent) SE.notify('还款：' + (cfg.name || cfg.id) + ' ' + _fmt(payment) + '，剩余 ' + _fmt(st.principal) + '。');
          try { if (cfg.onSettle) cfg.onSettle(payment); } catch (e) {}
          if (st.principal <= 0) {
            st.principal = 0;
            if (!cfg.silent) SE.notify((cfg.name || cfg.id) + ' 已还清。');
            try { if (cfg.onPaidOff) cfg.onPaidOff(); } catch (e) {}
          }
        } else {
          st.missed++;
          if (!cfg.silent) SE.notify('你付不起 ' + (cfg.name || cfg.id) + ' 的还款（' + _fmt(payment) + '）。');
          try { if (cfg.onDefault) cfg.onDefault(payment); } catch (e) {}
        }
        continue;
      }

      // expense（默认）
      if (amt <= 0) continue;
      var V2 = _V();
      if (V2 && (V2.money || 0) >= amt) {
        _pay(-amt, cfg.id);
        if (!cfg.silent) SE.notify('支出：' + (cfg.name || cfg.id) + ' ' + _fmt(amt) + '。');
        try { if (cfg.onSettle) cfg.onSettle(amt); } catch (e) {}
      } else {
        st.missed++;
        st.arrears += amt;
        if (!cfg.silent) SE.notify('你付不起 ' + (cfg.name || cfg.id) + '（' + _fmt(amt) + '），欠款累积至 ' + _fmt(st.arrears) + '。');
        try { if (cfg.onDefault) cfg.onDefault(amt); } catch (e) {}
      }
    }
  }

  function _settleAll() {
    var V = _V();
    if (!V || V.statFreeze) return;
    if (typeof Time === 'undefined' || typeof Time.days !== 'number') return;
    var s = _store();
    if (!s) return;
    var today = Time.days;

    for (var i = 0; i < _order.length; i++) {
      var cfg = _entries[_order[i]];
      var st = s.entries[cfg.id];

      if (!_isActive(cfg)) {
        // 非激活期不结算也不欠账：快进 lastDay，避免重新激活时补结历史
        // （储蓄掉下起息线再回升不该一次性补发利息）
        if (st) st.lastDay = today;
        continue;
      }

      if (!st) {
        // 首次激活：建档，从今天起算周期，不补历史
        st = s.entries[cfg.id] = {
          lastDay: today,
          missed: 0,
          arrears: 0,
          principal: cfg.kind === 'debt' ? Math.round(_resolve(cfg.principal, 0)) : 0,
        };
        continue;
      }
      if (st.lastDay > today) st.lastDay = today; // 时间倒流（debug）防护
      _settleEntry(cfg, st, today);
    }
  }

  // ---------------- 结算提示注入（对标 skill-addon 独立消息系统） ----------------

  function _showNotices() {
    var s = _store();
    if (!s || !s.notices.length) return;
    try {
      var target = document.getElementById('passage-content') ||
                   document.querySelector('.passage');
      if (!target) return;
      var box = document.createElement('div');
      for (var i = 0; i < s.notices.length; i++) {
        var span = document.createElement('span');
        span.className = 'gold';
        span.textContent = s.notices[i];
        box.appendChild(span);
        box.appendChild(document.createElement('br'));
      }
      box.appendChild(document.createElement('br'));
      target.insertBefore(box, target.firstChild);
      s.notices = [];
    } catch (e) {}
  }

  // ---------------- 账本面板 <<susatoEconPanel>> ----------------

  function _panelHtml() {
    var s = _store();
    var rows = [];
    var V = _V();
    rows.push('<div>持有现金：' + _fmt((V && V.money) || 0) + '</div><br>');
    var shown = 0;
    for (var i = 0; i < _order.length; i++) {
      var cfg = _entries[_order[i]];
      var st = s ? s.entries[cfg.id] : null;
      var activeNow = _isActive(cfg);
      var hasResidue = st && (st.arrears > 0 || st.principal > 0);
      if (!activeNow && !hasResidue) continue;
      shown++;
      var amt = _resolve(cfg.amount, 0);
      var kindLabel = cfg.kind === 'income' ? '收入' : cfg.kind === 'debt' ? '债务' : '支出';
      var line = '<div><b>' + (cfg.name || cfg.id) + '</b>（' + kindLabel + '）<br>';
      line += '每 ' + cfg.period + ' 天 ' + _fmt(amt);
      if (st && typeof Time !== 'undefined') {
        var due = st.lastDay + cfg.period - Time.days;
        if (activeNow) line += '，距下次结算 ' + Math.max(due, 0) + ' 天';
      }
      if (st && st.principal > 0) line += '<br>剩余本金：' + _fmt(st.principal);
      if (st && st.arrears > 0) line += '<br><span class="red">累计欠款：' + _fmt(st.arrears) + '</span>';
      if (st && st.missed > 0) line += '<br><span class="red">违约次数：' + st.missed + '</span>';
      line += '</div><br>';
      rows.push(line);
    }
    if (!shown) rows.push('<div>目前没有周期性收支。</div>');
    return rows.join('');
  }

  function _registerPanelMacro() {
    try {
      if (typeof DefineMacroS === 'function') {
        DefineMacroS('susatoEconPanel', _panelHtml);
      }
    } catch (e) {}
  }

  // ---------------- 启动 ----------------

  function _setupHooks() {
    if (typeof $ === 'undefined') return;
    if (SE._hooksSetup) return;
    SE._hooksSetup = true;
    $(document).on(':passageend', function () {
      _settleAll();
      _showNotices(); // 兼容旧档残留的 $susatoEcon.notices 队列（state-addon 缺席时也是主路径）
      if (typeof SM.notifyFlush === 'function') SM.notifyFlush(); // 结算产生的统一消息当页立即可见（幂等）
    });
  }

  SM.onInit(function () {
    _store();
    _registerPanelMacro();
    _setupHooks();
  });

  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', function () {
      _registerPanelMacro();
      _setupHooks();
    });
  }
})();
