// npc-addon.js — NPC/关系注册框架
// 一行 register() 声明一个自定义关系条, 自动出现在 Social(社交)页的关系区,
// 数值变量交给 state-addon 托管(新档初始化+旧档补缺)。
// 渲染完全复用本体原生 widget(relation-box-simple / relation-text):
// 框架 boot.json 里有一条 SusatoTextAddon 注入, 在 Social 页的关系区插入一段
// 按注册表循环的 twee, 逐个构造与本体手写完全相同的配置对象。
//
// API:
//   SusatoModel.npc.register({
//     id: 'policeTrust',              // 唯一 id
//     name: '警局信任',                // 关系条标题
//     variable: 'policeReputation',   // 数值变量名(自动按 0 托管初始化)
//     icon: 'img/misc/icon/police.png',  // 可选图标
//     preText: '',                    // 可选前缀文本
//     visible: function () {},        // 可选显示条件, 返回 bool(默认恒真)
//     states: [                       // 等级描述表(relation-text 格式)
//       { requiredValue: 0,  color: 'red',  description: '……' },
//       ...
//     ],
//   })
//   SusatoModel.npc.list()   -> 当前应显示的注册项数组(供 Social 页 twee 循环)
//   SusatoModel.npc.count()  -> list().length
//   SusatoModel.npc.get(id)  -> 注册项

(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('npc-addon')) return; // 模块开关(起源管理器), 刷新后生效

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.npc) return; // load-once 守卫

  var _registry = {};
  var _order = [];

  function _initVar(cfg) {
    try {
      if (!cfg.variable) return;
      if (SM.vars) { SM.vars.define(cfg.variable, 0); return; }
      if (typeof State !== 'undefined' && State.variables && State.variables[cfg.variable] === undefined) {
        State.variables[cfg.variable] = 0;
      }
    } catch (e) {}
  }

  SM.npc = {
    register: function (cfg) {
      if (!cfg || !cfg.id || _registry[cfg.id]) return false;
      if (!cfg.variable || !Array.isArray(cfg.states) || !cfg.states.length) return false;
      _registry[cfg.id] = cfg;
      _order.push(cfg.id);
      _initVar(cfg);
      return true;
    },
    get: function (id) { return _registry[id]; },
    list: function () {
      var out = [];
      for (var i = 0; i < _order.length; i++) {
        var cfg = _registry[_order[i]];
        try { if (cfg.visible && !cfg.visible()) continue; } catch (e) { continue; }
        out.push(cfg);
      }
      return out;
    },
    count: function () { return SM.npc.list().length; },
  };

  // 兜底: 注册可能早于 state-addon 就绪, storyready 再补一次变量托管
  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', function () {
      for (var i = 0; i < _order.length; i++) _initVar(_registry[_order[i]]);
    });
  }
})();
