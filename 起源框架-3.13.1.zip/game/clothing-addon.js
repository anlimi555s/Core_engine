// ==================================================================
//  SusatoModel 衣服运行时注册框架 v1.0
//
//  一行 addClothing() 替代 JSON 文件 + ModdedClothesAddon + additionFile
//  全部中间层。图片放 img/clothes/{slot}/{normaliseFileName(variable)}/
//  即可，boot.json imgFileList 另走一次扫描同步。
//
//  SusatoModel.addClothing(slot, spec)
//    slot: 'upper' | 'lower' | 'feet' | 'head' | 'over_head' | ...
//    spec: { variable, name_cap(必填), + 任何想覆盖的字段 }
//  未指定的字段自动填该 slot 的默认值，index 自动分配。
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SC = window.SusatoModel.clothing = window.SusatoModel.clothing || {};

  // ==================== 字段默认值表（按 slot） ====================
  var BASE = {
    description: '', state_top_base: 'chest', state_base: 'waist',
    state_top: 'chest', state: 'waist',
    exposed_base: 0, exposed: 0,
    gender: 'n', femininity: 0, warmth: 0, cost: 500, plural: 0,
    colour: 0, colour_sidebar: 0, colour_combat: 0, colour_options: [],
    shop: ['clothing'], type: [],
    accessory: 0, accessory_colour: 0, accessory_colour_options: [],
    accessory_colour_sidebar: 0, accessory_colour_combat: 0,
    word: 'a', iconFile: 'placeholder.png', accIcon: 0,
    cursed: 0, location: 0, mainImage: 1, back_img: 0,
    name: '',  // auto-fill from variable if empty
  };

  var SLOT_DEFAULTS = {
    upper: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, sleeve_acc_img: 0,
      breast_img: 0, breast_acc_img: 0, penis_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    lower: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, rearresize: 0,
      one_piece: 0, skirt: 0, skirt_down: 0, short: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
      sleeve_img: 0, sleeve_acc_img: 0,
    },
    under_upper: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, breast_img: 0, breast_acc_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    under_lower: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
    },
    over_upper: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, breast_img: 0, breast_acc_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    over_lower: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0,
      skirt: 0, skirt_down: 0, short: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
    },
    head: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    over_head: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    face: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    neck: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    hands: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    handheld: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    legs: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    feet: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, plural: 1, heels: 0,
    },
  };

  // ==================== 核心注册函数 ====================
  function _buildItem(slot, spec) {
    var defs = SLOT_DEFAULTS[slot] || {};
    var item = {};

    // 合并 BASE + slot defaults + spec
    var keys = {};
    Object.keys(BASE).forEach(function (k) { keys[k] = 1; });
    Object.keys(defs).forEach(function (k) { keys[k] = 1; });
    if (spec) { Object.keys(spec).forEach(function (k) { keys[k] = 1; }); }

    Object.keys(keys).forEach(function (k) {
      if (spec && spec.hasOwnProperty(k)) {
        item[k] = spec[k];
      } else if (defs.hasOwnProperty(k)) {
        item[k] = defs[k];
      } else if (BASE.hasOwnProperty(k)) {
        item[k] = BASE[k];
      }
    });

    // auto-fill name from variable if missing
    if ((!item.name || item.name === '') && item.variable) {
      item.name = item.variable.toLowerCase();
    }
    // auto-fill name_cap from variable if missing
    if (!item.name_cap && item.cn_name_cap) {
      item.name_cap = item.cn_name_cap;
    }

    return item;
  }

  function _getNextIndex(slot) {
    try {
      var arr = setup.clothes[slot];
      if (!Array.isArray(arr) || arr.length === 0) return 0;
      var max = 0;
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && typeof arr[i].index === 'number' && arr[i].index > max) {
          max = arr[i].index;
        }
      }
      return max + 1;
    } catch (e) { return 0; }
  }

  function _inject(slot, spec) {
    if (typeof slot !== 'string') return false;
    try {
      if (typeof setup === 'undefined' || !setup.clothes) return false;
    } catch (e) { return false; }
    // 如果该 slot 数组尚未初始化，开一个空数组（不要 return false）
    if (!Array.isArray(setup.clothes[slot])) {
      setup.clothes[slot] = [];
    }

    var item = _buildItem(slot, spec);
    if (!item.variable) { return false; }

    // 去重：同 variable 不重复注册
    for (var i = 0; i < setup.clothes[slot].length; i++) {
      if (setup.clothes[slot][i] && setup.clothes[slot][i].variable === item.variable) {
        return false; // already registered
      }
    }

    item.index = (spec && spec.index && spec.index >= 0) ? spec.index : _getNextIndex(slot);
    if (!item.name || item.name === '') item.name = item.variable.toLowerCase();
    item.slot = slot;  // 商店"全部"视图用 _item.slot 定位物品所在槽位
    setup.clothes[slot].push(item);
    if (!_flushed) _injected.push(item); // flush 后统一校验; 晚注册的在 SC.add 里即时校验

    // 提示文件夹名（渲染器用 原始 variable 拼路径，不要 normaliseFileName）
    if (typeof console !== 'undefined') {
      console.log('[clothing-addon] ' + slot + '/' + item.variable + ' (index=' + item.index + ', folder=' + item.variable + ')');
    }
    return item;
  }

  // ==================== outfit 引用校验 ====================
  // 本体 getTrueWarmth / 商店人台按 (name, modder) 双等解析 outfit 配对，
  // 解析失败没有 undefined 防护，直接 "reading 'warmth'" 崩商店（Nightdress 案根因：
  // 框架把 name 自动小写化，引用里的大写字母永远配不上）。
  // 注册期把引用解析一遍，失败就报错并剥掉该 outfit 字段——宁可散件也不崩店。
  function _resolveRef(refSlot, refName, modder) {
    if (refName === 'broken' || refName === 'split') return true; // 本体损坏态占位，跳过
    var arr = setup.clothes[refSlot];
    if (!Array.isArray(arr)) return false;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].name === refName && arr[i].modder === modder) return true;
    }
    return false;
  }

  function _validateOutfit(item) {
    var bad = [];
    if (item.outfitPrimary && typeof item.outfitPrimary === 'object') {
      Object.keys(item.outfitPrimary).forEach(function (s) {
        if (!_resolveRef(s, item.outfitPrimary[s], item.modder)) {
          bad.push('outfitPrimary.' + s + ' -> "' + item.outfitPrimary[s] + '"');
        }
      });
      if (bad.length) delete item.outfitPrimary;
    }
    if (item.outfitSecondary) {
      var sec = item.outfitSecondary;
      if (!Array.isArray(sec) || sec.length % 2 !== 0) {
        bad.push('outfitSecondary 格式错误(须 [slot, name, ...] 偶数长度)');
        delete item.outfitSecondary;
      } else {
        for (var i = 0; i < sec.length; i += 2) {
          if (!_resolveRef(sec[i], sec[i + 1], item.modder)) {
            bad.push('outfitSecondary ' + sec[i] + ' -> "' + sec[i + 1] + '"');
          }
        }
        if (bad.length) delete item.outfitSecondary;
      }
    }
    if (bad.length && typeof console !== 'undefined') {
      console.error('[clothing-addon] ' + item.slot + '/' + item.variable +
        ' outfit 引用解析失败, 已剥除 outfit 字段防商店崩溃: ' + bad.join('; ') +
        ' (解析条件是 name+modder 双等, 注意 name 缺省时会从 variable 自动小写化)');
    }
    return bad.length === 0;
  }

  // ==================== 公共 API ====================
  var _queue = [];
  var _flushed = false;
  var _injected = []; // 本框架注册成功的物品, flush 后统一校验 outfit 引用

  function _flushClothing() {
    for (var i = 0; i < _queue.length; i++) {
      _inject(_queue[i].slot, _queue[i].spec);
    }
    _queue = [];
    _flushed = true;
    // 全部注入完再统一校验(引用可以指向队列里靠后注册的物品)
    for (var k = 0; k < _injected.length; k++) {
      try { _validateOutfit(_injected[k]); } catch (e) {}
    }
    _injected = [];
    // 切换为直接执行模式(晚注册的单件即时校验, 此时全量物品已在场)
    SC.add = function (slot, spec) {
      var it = _inject(slot, spec);
      if (it) { try { _validateOutfit(it); } catch (e) {} }
    };
    SC.addClothing = SC.add;
  }

  SC.add = function (slot, spec) {
    if (!slot || !spec) return;
    if (_flushed) { _inject(slot, spec); }
    else { _queue.push({ slot: slot, spec: spec }); }
  };
  SC.addClothing = SC.add;

  // ==================== 启动：挂到 susato-core 的共享 init 管道 ====================
  // 不再有自己的 :storyready 处理器和独立队列，全走 SusatoModel.onInit。
  // core 在 scriptFileList 排第一，flush 跑得最早；之后 breast-system
  // 的 fixClothingData 再处理——顺序由 scriptFileList 保证。
  var SM = window.SusatoModel || {};
  if (SM.onInit) {
    SM.onInit(function () {
      try { _flushClothing(); } catch (e) {}
    });
  }
})();
